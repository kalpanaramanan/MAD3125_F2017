package com.example.macstudent.employeeapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.macstudent.employeeapplication.model.Employee;

public class EmployeeDetailsActivity extends AppCompatActivity {

    Employee employee;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_details);

        if (getIntent().getExtras() != null){
            employee = (Employee) getIntent().getExtras().getSerializable("employeeObj");
            Toast.makeText(this,employee.toString(),Toast.LENGTH_SHORT).show();
        }
    }

    public static void startIntent(Context context) {
        context.startActivity(new Intent(context,EmployeeDetailsActivity.class));
    }

    public static void startIntent(Context context, Bundle bundle) {
        Intent intent = new Intent(context,EmployeeDetailsActivity.class);
        intent.putExtras(bundle);
        context.startActivity(intent);
    }
}
