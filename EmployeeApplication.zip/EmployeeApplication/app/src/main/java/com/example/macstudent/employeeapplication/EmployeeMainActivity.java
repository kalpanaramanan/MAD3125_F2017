package com.example.macstudent.employeeapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class EmployeeMainActivity extends AppCompatActivity {

    @InjectView(R.id.lstEmployee)
    ListView lstEmployee;

    String[] employeeName = {"Kalpana","Sai Praveen","Omika","Valarmathi","AlkaSels","Manoch","Elena","Navdeep","Richard","Kanoch"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_main);

        //Injected ButterKnife plugin
        ButterKnife.inject(this);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,employeeName);
        lstEmployee.setAdapter(arrayAdapter);

        lstEmployee.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView textView = (TextView)view;
                Log.d("Value : ",textView.getText().toString());
                Toast.makeText(EmployeeMainActivity.this,employeeName[i],Toast.LENGTH_SHORT).show();

                SharedPreferences sharedPreferences = getSharedPreferences("myPrefrences",MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("id",1);
                editor.putString("name","Kalapna");
                editor.apply(); //commit is used in older version of Android
            }
        });

    }
    // Implementation for the Menu.xml (three dots to the right hand coner to your application)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId()) {
            case R.id.add_action:
                Toast.makeText(EmployeeMainActivity.this,"Add Menu",Toast.LENGTH_SHORT).show();
                EmployeeFormActivity.startIntent(this);
                break;
            case R.id.action_setting:
                Toast.makeText(EmployeeMainActivity.this,"Setting Menu",Toast.LENGTH_SHORT).show();
                Bundle bundle = new Bundle();
                bundle.putString("name","Kalpana");
                EmployeeFormActivity.startIntent(this,bundle);
                break;

        }
        return(super.onOptionsItemSelected(item));
    }
}
