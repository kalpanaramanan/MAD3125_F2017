package com.example.macstudent.employeeapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.macstudent.employeeapplication.adapter.EmployeeAdapter;
import com.example.macstudent.employeeapplication.model.Employee;

import java.util.ArrayList;
import java.util.Random;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class EmployeeFormActivity extends AppCompatActivity {

    @InjectView(R.id.lstEmployee)
    ListView lstEmployee;

    ArrayList<Employee> employeeArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_form);

        ButterKnife.inject(this);

        initData();

        final EmployeeAdapter employeeAdapter = new EmployeeAdapter(this,employeeArrayList);
        lstEmployee.setAdapter(employeeAdapter);

        lstEmployee.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Employee employee = employeeArrayList.get(i);
               // employeeAdapter.add(new Employee(new Random().nextInt(100),"TEST-TEST"));
                Bundle bundle = new Bundle();
                bundle.putSerializable("employeeObj",employee);
                EmployeeDetailsActivity.startIntent(EmployeeFormActivity.this,bundle);
            }
        });
        //employeeArrayList.add(new Employee(12,"Hello Lambton College"));
    }

    public static void startIntent(Context context) {
        context.startActivity(new Intent(context,EmployeeFormActivity.class));
    }

    public static void startIntent(Context context, Bundle bundle) {
        Intent intent = new Intent(context,EmployeeFormActivity.class);
        intent.putExtras(bundle);
        context.startActivity(intent);
    }

    private void initData(){
        employeeArrayList = new ArrayList<>();
        employeeArrayList.add(new Employee(1,"Kalpana"));
        employeeArrayList.add(new Employee(2,"Sai Praveen"));
        employeeArrayList.add(new Employee(3,"Omika"));
        employeeArrayList.add(new Employee(4,"Manoch"));
        employeeArrayList.add(new Employee(5,"Elena"));
        employeeArrayList.add(new Employee(6,"Navdeep"));
        employeeArrayList.add(new Employee(7,"Suresha"));
        employeeArrayList.add(new Employee(8,"Kanoch"));
        employeeArrayList.add(new Employee(9,"Alka Sels"));
    }

    void getSharedPrefrences(){
        SharedPreferences sharedPreferences = getSharedPreferences("myPrefrences",MODE_PRIVATE);

       int id = sharedPreferences.getInt("id",-1);
       String name = sharedPreferences.getString("name","null");

        if (name != null && id != -1){
            //Log.d("PREF",String.format("%d id [ %d name ]"));
            Log.d("PREF",id + " " + name);
        }
    }
}
