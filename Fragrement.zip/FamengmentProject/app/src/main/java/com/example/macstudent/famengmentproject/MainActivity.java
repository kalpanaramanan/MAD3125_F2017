package com.example.macstudent.famengmentproject;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements FirstFragment.OnFragmentInteractionListener{

    TextView lblHeader;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lblHeader = (TextView)findViewById(R.id.lblHeader);

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void setData(String str) {
        Toast.makeText(this,str,Toast.LENGTH_SHORT).show();
        lblHeader.setText("KAlpana -- Welcome to Fragment Programming");
    }
}
