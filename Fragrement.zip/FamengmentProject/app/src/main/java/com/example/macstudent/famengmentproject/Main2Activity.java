package com.example.macstudent.famengmentproject;

import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity implements  FirstFragment.OnFragmentInteractionListener{

    Button btnFirst,btnSecond;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnFirst = (Button)findViewById(R.id.firstFragmentClick);
        btnSecond = (Button)findViewById(R.id.secondFragmentClick);

        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.container,new Fragment());
        fragmentTransaction.commit();

        btnFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container,new FirstFragment());
               // fragmentTransaction.add(R.id.container,new FirstFragment());
               // fragmentTransaction.remove(new PlusOneFragment());

                fragmentTransaction.commit();
            }
        });

        btnSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container,new PlusOneFragment());
                //fragmentTransaction.add(R.id.container,new PlusOneFragment());
               // fragmentTransaction.remove(new FirstFragment());
                fragmentTransaction.commit();
            }
        });
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void setData(String str) {

    }
}
