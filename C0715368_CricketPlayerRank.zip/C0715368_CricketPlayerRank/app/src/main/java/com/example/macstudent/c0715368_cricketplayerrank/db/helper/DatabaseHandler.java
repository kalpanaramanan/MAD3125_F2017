package com.example.macstudent.c0715368_cricketplayerrank.db.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by macstudent on 2017-12-01.
 */
public class DatabaseHandler extends SQLiteOpenHelper {


    private static final int DATABASE_VERSION = 4;
    private static final String DATABASE_NAME = "cricketPlayerManager";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_CRICKET_PLAYER_TABLE = "CREATE TABLE " + DBCricketPlayer.TABLE_CRICKET_PLAYER + "("
                + DBCricketPlayer.KEY_ID + " INTEGER PRIMARY KEY,"
                + DBCricketPlayer.KEY_NAME + " TEXT,"
                + DBCricketPlayer.KEY_GENDER + " TEXT,"
                + DBCricketPlayer.KEY_BIRTH_DATE + " TEXT,"
                + DBCricketPlayer.KEY_PLAYER_CATERGORY + " TEXT,"
                + DBCricketPlayer.KEY_TEAM_COUNTRY + " TEXT,"
                + DBCricketPlayer.KEY_NO_OF_TEST_MATCH + " TEXT,"
                + DBCricketPlayer.KEY_NO_OF_ONE_DAY_MATCH + " TEXT,"
                + DBCricketPlayer.KEY_NO_OF_TEST_CATCHES + " TEXT,"
                + DBCricketPlayer.KEY_NO_OF_RUNS + " TEXT,"
                + DBCricketPlayer.KEY_NO_OF_WICKETS + " TEXT,"
                + DBCricketPlayer.KEY_NO_OF_TEST_STUMPING + " TEXT,"
                + DBCricketPlayer.KEY_NO_OF_TEST_TOTAL + " TEXT"
                + ")";
        db.execSQL(CREATE_CRICKET_PLAYER_TABLE);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + DBCricketPlayer.TABLE_CRICKET_PLAYER);
        onCreate(db);
    }
}
