package com.example.macstudent.c0715368_cricketplayerrank.db.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.macstudent.c0715368_cricketplayerrank.db.model.CricketPlayer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by macstudent on 2017-12-01.
 */

public class DBCricketPlayer {


    static final String TABLE_CRICKET_PLAYER = "CricketPlayer";

    static final String KEY_ID = "playerID";
    static final String KEY_NAME = "playerName";
    static final String KEY_GENDER = "gender";
    static final String KEY_BIRTH_DATE = "BirthDate";
    static final String KEY_PLAYER_CATERGORY = "playerCatergory";
    static final String KEY_TEAM_COUNTRY = "teamCountry";
    static final String KEY_NO_OF_TEST_MATCH = "noOfTestMatch";
    static final String KEY_NO_OF_ONE_DAY_MATCH = "noOfOneDayMatch";
    static final String KEY_NO_OF_TEST_CATCHES = "noOfCatches";
    static final String KEY_NO_OF_RUNS = "noOfTestRuns";
    static final String KEY_NO_OF_WICKETS = "noOfTestWickets";
    static final String KEY_NO_OF_TEST_STUMPING = "noOfTestStumping";
    static final String KEY_NO_OF_TEST_TOTAL = "Total";



    private DatabaseHandler databaseHandler;
    private Context context;

    public DBCricketPlayer(Context context) {
        this.context = context;
    }


    public void addNewPlayer(CricketPlayer cricketPlayer) {

        databaseHandler = new DatabaseHandler(context);

        SQLiteDatabase db = databaseHandler.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, cricketPlayer.getPlayerName());
        values.put(KEY_GENDER, cricketPlayer.getGender());
        values.put(KEY_BIRTH_DATE, cricketPlayer.getBirthDate());
        values.put(KEY_PLAYER_CATERGORY, cricketPlayer.getPlayerCatergory());
        values.put(KEY_TEAM_COUNTRY, cricketPlayer.getTeamCountry());
        values.put(KEY_NO_OF_TEST_MATCH, cricketPlayer.getNoOfTestMatch());
        values.put(KEY_NO_OF_ONE_DAY_MATCH, cricketPlayer.getNoOfOneDayMatch());
        values.put(KEY_NO_OF_TEST_CATCHES, cricketPlayer.getNoOfCatches());
        values.put(KEY_NO_OF_RUNS, cricketPlayer.getNoOfTestRuns());
        values.put(KEY_NO_OF_WICKETS, cricketPlayer.getNoOfTestWickets());
        values.put(KEY_NO_OF_TEST_STUMPING, cricketPlayer.getNoOfTestStumping());
        values.put(KEY_NO_OF_TEST_TOTAL, cricketPlayer.getTotal());

        db.insert(TABLE_CRICKET_PLAYER, null, values);
        db.close();

    }
    public List<CricketPlayer> getAllCricketPlayer() {

        databaseHandler = new DatabaseHandler(context);
        List<CricketPlayer> cricketPlayerArrayList = new ArrayList<CricketPlayer>();

        String selectQuery = "SELECT  * FROM " + TABLE_CRICKET_PLAYER + " Order by "+ KEY_NO_OF_TEST_TOTAL + " ASC ";

        SQLiteDatabase db = databaseHandler.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                CricketPlayer cricketPlayer = new CricketPlayer();
                cricketPlayer.setPlayerID(Integer.parseInt(cursor.getString(0)));
                cricketPlayer.setPlayerName(cursor.getString(1));

                cricketPlayerArrayList.add(cricketPlayer);
            } while (cursor.moveToNext());
        }

        return cricketPlayerArrayList;
    }

}
