package com.example.macstudent.c0715368_cricketplayerrank.db.model;

import java.io.Serializable;

/**
 * Created by macstudent on 2017-12-01.
 */

public class CricketPlayer implements Serializable {

    private int playerID;
    private String playerName;
    private String gender;
    private String BirthDate;
    private String playerCatergory;
    private String teamCountry;
    private String noOfTestMatch;
    private String noOfOneDayMatch;
    private String noOfCatches;
    private String noOfTestRuns;
    private String noOfTestWickets;
    private String noOfTestStumping;
    private String Total;

    public CricketPlayer() {
    }

    public CricketPlayer(int playerID, String playerName, String gender, String birthDate, String playerCatergory, String teamCountry, String noOfTestMatch, String noOfOneDayMatch, String noOfCatches, String noOfTestRuns, String noOfTestWickets, String noOfTestStumping, String total) {
        this.playerID = playerID;
        this.playerName = playerName;
        this.gender = gender;
        BirthDate = birthDate;
        this.playerCatergory = playerCatergory;
        this.teamCountry = teamCountry;
        this.noOfTestMatch = noOfTestMatch;
        this.noOfOneDayMatch = noOfOneDayMatch;
        this.noOfCatches = noOfCatches;
        this.noOfTestRuns = noOfTestRuns;
        this.noOfTestWickets = noOfTestWickets;
        this.noOfTestStumping = noOfTestStumping;
        Total = total;
    }

    public CricketPlayer(String playerName, String gender, String birthDate, String playerCatergory, String teamCountry, String noOfTestMatch, String noOfOneDayMatch, String noOfCatches, String noOfTestRuns, String noOfTestWickets, String noOfTestStumping, String total) {
        this.playerName = playerName;
        this.gender = gender;
        BirthDate = birthDate;
        this.playerCatergory = playerCatergory;
        this.teamCountry = teamCountry;
        this.noOfTestMatch = noOfTestMatch;
        this.noOfOneDayMatch = noOfOneDayMatch;
        this.noOfCatches = noOfCatches;
        this.noOfTestRuns = noOfTestRuns;
        this.noOfTestWickets = noOfTestWickets;
        this.noOfTestStumping = noOfTestStumping;
        Total = total;
    }

    public int getPlayerID() {
        return playerID;
    }

    public void setPlayerID(int playerID) {
        this.playerID = playerID;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthDate() {
        return BirthDate;
    }

    public void setBirthDate(String birthDate) {
        BirthDate = birthDate;
    }

    public String getPlayerCatergory() {
        return playerCatergory;
    }

    public void setPlayerCatergory(String playerCatergory) {
        this.playerCatergory = playerCatergory;
    }

    public String getTeamCountry() {
        return teamCountry;
    }

    public void setTeamCountry(String teamCountry) {
        this.teamCountry = teamCountry;
    }

    public String getNoOfTestMatch() {
        return noOfTestMatch;
    }

    public void setNoOfTestMatch(String noOfTestMatch) {
        this.noOfTestMatch = noOfTestMatch;
    }

    public String getNoOfOneDayMatch() {
        return noOfOneDayMatch;
    }

    public void setNoOfOneDayMatch(String noOfOneDayMatch) {
        this.noOfOneDayMatch = noOfOneDayMatch;
    }

    public String getNoOfCatches() {
        return noOfCatches;
    }

    public void setNoOfCatches(String noOfCatches) {
        this.noOfCatches = noOfCatches;
    }

    public String getNoOfTestRuns() {
        return noOfTestRuns;
    }

    public void setNoOfTestRuns(String noOfTestRuns) {
        this.noOfTestRuns = noOfTestRuns;
    }

    public String getNoOfTestWickets() {
        return noOfTestWickets;
    }

    public void setNoOfTestWickets(String noOfTestWickets) {
        this.noOfTestWickets = noOfTestWickets;
    }

    public String getNoOfTestStumping() {
        return noOfTestStumping;
    }

    public void setNoOfTestStumping(String noOfTestStumping) {
        this.noOfTestStumping = noOfTestStumping;
    }

    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        Total = total;
    }
}
