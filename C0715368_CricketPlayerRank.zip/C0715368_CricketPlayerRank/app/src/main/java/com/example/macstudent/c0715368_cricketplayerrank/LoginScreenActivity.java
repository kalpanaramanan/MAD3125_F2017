package com.example.macstudent.c0715368_cricketplayerrank;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginScreenActivity extends AppCompatActivity {

    Button btnLogin;
    EditText txtUsername,txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        btnLogin = (Button)findViewById(R.id.btnLogin);
        txtUsername = (EditText)findViewById(R.id.txtUsername);
        txtPassword = (EditText)findViewById(R.id.txtPassword);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( (txtUsername.getText().toString().equals("kalpanar@gmail.com"))&& (txtPassword.getText().toString().equals("admin@123")) ){
                    Intent intent = new Intent(getApplicationContext(),AddNewPlayersScreenActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}
