package com.example.macstudent.c0715368_cricketplayerrank;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.macstudent.c0715368_cricketplayerrank.adapter.CricketPlayerAdapter;
import com.example.macstudent.c0715368_cricketplayerrank.db.helper.DBCricketPlayer;
import com.example.macstudent.c0715368_cricketplayerrank.db.model.CricketPlayer;

import java.util.ArrayList;

public class ListAllCricketPlayerActivity extends AppCompatActivity {

    CricketPlayerAdapter cricketPlayerAdapter;
    ListView lstCricketPlayer;
    ArrayList<CricketPlayer> cricketPlayersList;

    public static void startIntent(Context context)
    {
        context.startActivity(new Intent(context,ListAllCricketPlayerActivity.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_all_cricket_player);

        lstCricketPlayer = (ListView)findViewById(R.id.lstCricketPlayers);

        DBCricketPlayer dbCricketPlayer = new DBCricketPlayer(this);

        cricketPlayersList = (ArrayList<CricketPlayer>) dbCricketPlayer.getAllCricketPlayer();

        cricketPlayerAdapter = new CricketPlayerAdapter(this,cricketPlayersList);
        lstCricketPlayer.setAdapter(cricketPlayerAdapter);

        lstCricketPlayer.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                CricketPlayer e = cricketPlayersList.get(i);
                Toast.makeText(ListAllCricketPlayerActivity.this, " Data "+e.getPlayerName(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ListAllCricketPlayerActivity.this,DetailedViewActivity.class);
                intent.putExtra("cricket",e);
                startActivity(intent);
            }
        });
    }
}
