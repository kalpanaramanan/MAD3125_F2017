package com.example.macstudent.c0715368_cricketplayerrank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.macstudent.c0715368_cricketplayerrank.db.helper.DBCricketPlayer;
import com.example.macstudent.c0715368_cricketplayerrank.db.model.CricketPlayer;

import java.util.ArrayList;
import java.util.List;

public class AddNewPlayersScreenActivity extends AppCompatActivity {

    Button btnSave;
    EditText txtPlayerName, txtRuns, txtCatches, txtWickets, txtTestMatch, txtOneDayMatch, txtStumping, txtTotal;
    CheckBox chBatsaman, chWicketKeeper, chBowler;
    RadioButton rbMale, rbFemale;
    Spinner spDay, spMonth, spYear, spCountry;
    String playerCatergory, dateOfBirth, gender, day, month, year, country = "";
    DBCricketPlayer dbCricketPlayer;
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_players_screen);

        dbCricketPlayer = new DBCricketPlayer(this);
        btnSave = (Button) findViewById(R.id.btnAddNewPlayer);
        txtPlayerName = (EditText) findViewById(R.id.txtPlayerName);


        radioGroup = (RadioGroup) findViewById(R.id.radioButtonGroupGender);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.rbFemale) {
                    gender = "Female";
                } else if (i == R.id.rbmale) {
                    gender = "Male";
                }
            }
        });

        spDay = (Spinner) findViewById(R.id.spDay);
        spDay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                day = spDay.getSelectedItem().toString();
            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMonth = (Spinner) findViewById(R.id.spMonth);
        spMonth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                month = spMonth.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spYear = (Spinner) findViewById(R.id.spYear);
        spYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                year = spYear.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        chBatsaman = (CheckBox) findViewById(R.id.chbBatsman);
        chBatsaman.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (chBatsaman.isChecked()) {
                    playerCatergory += chBatsaman.getText().toString() + ",";
                }
            }
        });

        chBowler = (CheckBox) findViewById(R.id.chbBowler);
        chBowler.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (chBowler.isChecked()) {
                    playerCatergory += chBowler.getText().toString() + ",";
                }
            }
        });

        chWicketKeeper = (CheckBox) findViewById(R.id.chbWicketKeeper);
        chWicketKeeper.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (chWicketKeeper.isChecked()) {
                    playerCatergory += chWicketKeeper.getText().toString() + ",";
                }
            }
        });

        spCountry = (Spinner) findViewById(R.id.spCountry);
        spCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                country = spCountry.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        txtTestMatch = (EditText) findViewById(R.id.txtTestMatch);
        txtOneDayMatch = (EditText) findViewById(R.id.txtOneDayMatch);
        txtCatches = (EditText) findViewById(R.id.txtCatch);
        txtRuns = (EditText) findViewById(R.id.txtRuns);
        txtWickets = (EditText) findViewById(R.id.txtWickets);
        txtStumping = (EditText) findViewById(R.id.txtStumpings);


        Log.d("Insert: ", "Inserting ..");
        //dbCricketPlayer.addNewPlayer(new CricketPlayer("Kalpana","Female","17-05-1990","Bowler","India","2","5","1","100","4","0","500"));

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dateOfBirth = day + "-" + month + "-" + year;

                int totals = Integer.parseInt(txtTestMatch.getText().toString()) +
                        Integer.parseInt(txtOneDayMatch.getText().toString()) +
                        Integer.parseInt(txtCatches.getText().toString()) +
                        Integer.parseInt(txtRuns.getText().toString()) +
                        Integer.parseInt(txtWickets.getText().toString()) +
                        Integer.parseInt(txtStumping.getText().toString());

                final String tots = String.valueOf(totals);
                dbCricketPlayer.addNewPlayer(new CricketPlayer(txtPlayerName.getText().toString(), gender, dateOfBirth, playerCatergory, country, txtTestMatch.getText().toString(), txtOneDayMatch.getText().toString(), txtCatches.getText().toString(), txtRuns.getText().toString(), txtWickets.getText().toString(), txtStumping.getText().toString(), tots));

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.onCLickLstCricketPlayers:
                ListAllCricketPlayerActivity.startIntent(this);
                break;

        }
        return (super.onOptionsItemSelected(item));
    }

}
