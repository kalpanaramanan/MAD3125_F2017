package com.example.macstudent.c0715368_cricketplayerrank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.macstudent.c0715368_cricketplayerrank.db.model.CricketPlayer;

public class DetailedViewActivity extends AppCompatActivity {

    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_view);

        textView = (TextView)findViewById(R.id.edtName);
        Bundle bundle = getIntent().getExtras();
        CricketPlayer cricketPlayer = (CricketPlayer)bundle.getSerializable("cricket");
        String data = cricketPlayer.getPlayerName().toString() ;
        textView.setText(data.toString());
    }
}
