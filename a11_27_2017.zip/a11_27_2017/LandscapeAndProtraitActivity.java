package com.example.macstudent.a11_27_2017;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class LandscapeAndProtraitActivity extends AppCompatActivity {

    Button btnNext;
    public static final String name = "name";
    public static final String id = "id";
    RadioGroup radioGroup;
    CheckBox checkBox;
    ToggleButton toggleButton;
    Switch aSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landscape_and_protrait);


        radioGroup = (RadioGroup)findViewById(R.id.myRadioGroup);
        btnNext = (Button)findViewById(R.id.btnLogin);
        checkBox = (CheckBox)findViewById(R.id.myCheckBoxOne);
        toggleButton = (ToggleButton)findViewById(R.id.myToggleButton);
        aSwitch = (Switch)findViewById(R.id.mySwitch) ;

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
                intent.putExtra(name,"Lambton College");
                intent.putExtra(id,1);
                startActivity(intent);
            }
        });
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                if (i == R.id.radioButtonFirst) {
                    Toast.makeText(LandscapeAndProtraitActivity.this, "Clicked on First Radio Button", Toast.LENGTH_SHORT).show();
                }else  if (i == R.id.radioButtonSecond) {
                    Toast.makeText(LandscapeAndProtraitActivity.this, "Clicked on Second Radio Button", Toast.LENGTH_SHORT).show();
                }else  if (i == R.id.radioButtonThird) {
                    Toast.makeText(LandscapeAndProtraitActivity.this, "Clicked on Third Radio Button", Toast.LENGTH_SHORT).show();
                }
            }
        });

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (checkBox.isChecked()){
                   // Toast.makeText(LandscapeAndProtraitActivity.this, "Selected CheckBox", Toast.LENGTH_SHORT).show();
                    toggleButton.setChecked(true);
                    aSwitch.setChecked(true);
                }else{
                    //Toast.makeText(LandscapeAndProtraitActivity.this, "UnSelected CheckBox", Toast.LENGTH_SHORT).show();
                    toggleButton.setChecked(false);
                    aSwitch.setChecked(false);
                }

            }
        });

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "Landscape", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Portrait", Toast.LENGTH_SHORT).show();
        }
    }
}

