package com.example.macstudent.a11_27_2017;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    TextView txtTitle ;
    SeekBar seekBar;
    RatingBar ratingBar;
    ProgressBar progressBar;
    Spinner spinner,mySpinner2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtTitle = (TextView) findViewById(R.id.txtTitle);
        seekBar = (SeekBar) findViewById(R.id.mySeekBar);
        ratingBar = (RatingBar) findViewById(R.id.myRatingBar);
        progressBar = (ProgressBar) findViewById(R.id.myProgressBar);
        spinner = (Spinner) findViewById(R.id.mySpinner);
        mySpinner2 = (Spinner)findViewById(R.id.mySpinner2);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if (bundle.containsKey(LandscapeAndProtraitActivity.name)) {
                txtTitle.setText((Integer) bundle.get(LandscapeAndProtraitActivity.id) + " " + String.valueOf(bundle.get(LandscapeAndProtraitActivity.name)));
            } else {
                txtTitle.setText("No DATA NAME");
            }

        } else {
            txtTitle.setText("No DATA");
        }

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Toast.makeText(SecondActivity.this, "Value :" + i, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                Toast.makeText(SecondActivity.this, "Value :" + v, Toast.LENGTH_SHORT).show();
            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(SecondActivity.this, spinner.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        // DYNAMICALLY ADDING DATA TO THE LIST -- https://www.mkyong.com/android/android-spinner-drop-down-list-example/
       // /*
        List<String> list = new ArrayList<String>();
        list.add("list 1");
        list.add("list 2");
        list.add("list 3");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.select_dialog_multichoice);
        mySpinner2.setAdapter(dataAdapter);

        //MODIFY after new item added
        list.add("LIST 4 ");
        //dataAdapter.notifyDataSetChanged();
        // */
    }
}
