package com.example.macstudent.c0715368_madf3125_finalexamcode;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;


import com.example.macstudent.c0715368_madf3125_finalexamcode.adapter.LocationAdapter;
import com.example.macstudent.c0715368_madf3125_finalexamcode.model.Location;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    ArrayList<Location> dataModels;
    ListView listView;
    private static LocationAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


      //  Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
       // setSupportActionBar(toolbar);

        listView=(ListView)findViewById(R.id.myCountryList);
        dataModels= new ArrayList<>();

        dataModels.add(new Location( 1,"My Home", "43.774427", "-79.231582"));
        dataModels.add(new Location( 2, "My Job", "43.259971","-79.880114"));
        dataModels.add(new Location( 3, "CN Tower", "43.642566","-79.387057"));
         dataModels.add(new Location( 4, " Niagra Fall, Canada", "43.077275","-79.075320"));
         dataModels.add(new Location( 5, " Lambton College In Toronto", "43.6532","-79.3832"));
         dataModels.add(new Location( 6, " Statue of Liberty", "40.690498","-74.046500"));
         dataModels.add(new Location( 7, " Eiffel Tower", "48.858376","2.294469"));
         dataModels.add(new Location( 8, " Mumbai, India", "18.921984","72.834654"));
         dataModels.add(new Location( 9, " Mt. Everest", "27.987850","86.925026"));
         dataModels.add(new Location( 10, " Taj Mahal", "27.175015","78.042155"));

        adapter= new LocationAdapter(dataModels,getApplicationContext());

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Location dataModel= dataModels.get(position);

                Toast.makeText(MainActivity.this,"Selected on "+dataModel.getLocationName(),Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,DisplayMapsActivity.class);
                intent.putExtra("dataModel",dataModel);
                startActivity(intent);


            }
        });

    }

}
