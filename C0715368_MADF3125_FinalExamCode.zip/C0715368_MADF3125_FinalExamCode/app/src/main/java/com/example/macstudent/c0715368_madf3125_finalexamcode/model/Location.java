package com.example.macstudent.c0715368_madf3125_finalexamcode.model;

import java.io.Serializable;

/**
 * Created by macstudent on 2017-12-13.
 */

public class Location implements Serializable{

    private int LocationId;
    private String LocationName;
    private String Lontitude;
    private String Latitude;

    public Location() {
    }

    public Location(String locationName, String lontitude, String latitude) {
        LocationName = locationName;
        Lontitude = lontitude;
        Latitude = latitude;
    }

    public Location(int locationId, String locationName, String lontitude, String latitude) {
        LocationId = locationId;
        LocationName = locationName;
        Lontitude = lontitude;
        Latitude = latitude;
    }

    public int getLocationId() {
        return LocationId;
    }

    public void setLocationId(int locationId) {
        LocationId = locationId;
    }

    public String getLocationName() {
        return LocationName;
    }

    public void setLocationName(String locationName) {
        LocationName = locationName;
    }

    public String getLontitude() {
        return Lontitude;
    }

    public void setLontitude(String lontitude) {
        Lontitude = lontitude;
    }

    public String getLatitude() {
        return Latitude;
    }

    public void setLatitude(String latitude) {
        Latitude = latitude;
    }
}
