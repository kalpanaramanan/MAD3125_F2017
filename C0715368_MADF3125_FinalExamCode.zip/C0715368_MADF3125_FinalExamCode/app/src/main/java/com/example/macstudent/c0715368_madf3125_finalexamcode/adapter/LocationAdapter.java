package com.example.macstudent.c0715368_madf3125_finalexamcode.adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macstudent.c0715368_madf3125_finalexamcode.R;
import com.example.macstudent.c0715368_madf3125_finalexamcode.model.Location;

import java.util.ArrayList;

import static android.R.attr.data;
import static com.example.macstudent.c0715368_madf3125_finalexamcode.R.id.parent;

/**
 * Created by macstudent on 2017-12-13.
 */

public class LocationAdapter extends ArrayAdapter<Location> implements View.OnClickListener{

    private ArrayList<Location> dataSet;
    Context mContext;


    // View lookup cache
    private static class ViewHolder {
        TextView txtLocationId;
        TextView txtLocationName;
        TextView txtLongtitude;
        TextView txtLatitude;
    }

   public LocationAdapter(ArrayList<Location> data, Context context) {
        super(context, R.layout.row_country_list, data);
        this.dataSet = data;
        this.mContext=context;
    }


    @Override
    public void onClick(View v) {

        int position=(Integer) v.getTag();
        Object object= getItem(position);
        Location dataModel=(Location) object;

        switch (v.getId())
        {
            case R.id.myCountryList:
                Toast.makeText(getContext(),"data",Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Location dataModel = getItem(position);

        ViewHolder viewHolder;

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.row_country_list, parent, false);
            viewHolder.txtLocationId = (TextView) convertView.findViewById(R.id.txtLocationId);
            viewHolder.txtLocationName = (TextView) convertView.findViewById(R.id.txtLocationName);
            viewHolder.txtLongtitude = (TextView) convertView.findViewById(R.id.txtLongitude);
            viewHolder.txtLatitude = (TextView) convertView.findViewById(R.id.txtLatitude);

            result=convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }

        lastPosition = position;

        viewHolder.txtLocationId.setText(String.valueOf(dataModel.getLocationId()));
        viewHolder.txtLocationName.setText(dataModel.getLocationName());
        viewHolder.txtLongtitude.setText(dataModel.getLontitude());
        viewHolder.txtLatitude.setText(dataModel.getLatitude());

        viewHolder.txtLocationId.setOnClickListener(this);
        viewHolder.txtLocationId.setTag(position);
        // Return the completed view to render on screen
        return convertView;
    }
}




