package com.example.macstudent.linearlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

public class LinearActivity extends AppCompatActivity {

    EditText edtNumber1, edtNumber2;
    TextView lblResult;
    int n1,n2,res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.linearlayout);
        edtNumber1 = (EditText) findViewById(R.id.edtNum1);
        edtNumber2 = (EditText) findViewById(R.id.edtNum2);
        lblResult = (TextView)findViewById(R.id.lblResult);


    }

        public void myClickOnButton(View view) {

            int a,b,c;

            if(edtNumber1.getText().toString().length()!=0 )
            {
                n1 = Integer.parseInt(edtNumber1.getText().toString());
            }else
            {
                edtNumber1.setError("Enter Number 1");
                return;
            }


            if(edtNumber2.getText().toString().length()!=0 )
            {
                n2 = Integer.parseInt(edtNumber2.getText().toString());
            }else
            {
                edtNumber2.setError("Enter Number 2");
                return;
            }


            switch (view.getId()) {
                case R.id.btnAdd: {
                    res = n1 + n2;
                    lblResult.setText("Add: "+String.valueOf(res));
                }
                break;
                case R.id.btnSub: {
                    res = n1 - n2;
                    lblResult.setText("Sub: "+String.valueOf(res));
                }
                break;
                case R.id.btnMul: {
                    res = n1 * n2;
                    lblResult.setText("Mul: "+String.valueOf(res));
                }
                break;
                case R.id.btnDiv: {
                    res = n1 / n2;
                    lblResult.setText("Div: "+String.valueOf(res));
                }
                break;
            }
            //finish(); -- will terminate your screen
        }


}